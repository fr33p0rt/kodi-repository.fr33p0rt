#### 0.7.6
* Pairing

#### 0.7.5
* Pairing preparation 
* FAQ (en + cz)

#### 0.7.4
* SSL verify option

#### 0.7.3
* Channel filtering
* Licence text
* inputstream.adaptive dependency removed
* Code refactoring 

#### 0.7.2
* Channel logos
* BeautifulSoup4 dependency removed

#### 0.7.1
* Fixed for new web pages

#### 0.7.0
* First public release
