#### 0.7.2
* Channel logos
* BeautifulSoup4 dependency removed

#### 0.7.1
* Fixed for new web pages

#### 0.7.0
* First public release
