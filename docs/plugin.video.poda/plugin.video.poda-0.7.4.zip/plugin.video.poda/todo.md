#### TODO

* [ ] Resolution preset
* [ ] Channel logos
