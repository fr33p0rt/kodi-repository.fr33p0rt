# -*- coding: utf-8 -*-
# Author: fr33p0rt
# License GPLv3

import requests
import json
import fnmatch

from ..cfg.cfg import Filter

class Poda:

    URL = 'https://live.poda.tv/'
    URL_CHANNELS = 'https://live.poda.tv/api/getSources'
    URL_LOGO = 'https://red-cache.poda.4net.tv/channel/logo/{}.png'
    URL_PAIR = 'https://live.poda.tv/unsecured-api/pairBrowserByPairingCode/'
    cookies = None
    channels = []

    PHPSESSID = ''
    device_token = ''

    def get_sources_json(self, verify_ssl):
        r = requests.post(self.URL_CHANNELS, cookies=self.cookies, headers={'Referer': self.URL}, verify=verify_ssl)
        return json.loads(r.content)

    def get_channels(self, cfg):
        for i in self.get_sources_json(cfg.verify_ssl)['channels']:
            if (cfg.filter == Filter.SUPPRESS and not any((fnmatch.fnmatchcase(i['name'].encode('utf-8'), f)) for f in cfg.filter_items)) or \
               (cfg.filter == Filter.ONLY and any((fnmatch.fnmatchcase(i['name'].encode('utf-8'), f)) for f in cfg.filter_items)) or \
               cfg.filter == Filter.OFF:
                self.channels.append({'id': str(i['id']), 'name': i['name'], 'img': self.URL_LOGO.format(i['id'])}) #  + str(len(i['content_sources']))
        return self.channels

    def get_stream(self, cfg, ch_id):
        for i in self.get_sources_json(cfg.verify_ssl)['channels']:
            if i['id'] == ch_id:
                return i['content_sources'][0]['stream_profile_urls']['adaptive']

    def set_cookies(self, cookies):
        self.cookies = cookies
